package GameRental;

import java.util.Scanner;

public class Source {
    static String[] mobile = {"Samsung S8", "One Plus 8","Sony Experia"};
    static String[] tv = {"VU 55 Inches", "Sony TV", "Samsung Tv"};
    static String[] electronics = {"Speakers", "DSLR Cameras", "Security Cameras"};


    public static void main(String args[]) throws Exception {
        Scanner scan = new Scanner(System.in);
        String input = scan.next();

        switch (input.toLowerCase()) {
            case "mobile": getmobile();
                break;
            case "tv": getTV();
                break;
            case "electronics": getelectronic();
                break;

            default: System.out.println("No Products Available");
                break;
        }
        scan.close();

    }

    public static void getmobile(){
        for(String mobileName: mobile)
            System.out.println(mobileName);
    }

    public static void getTV(){
        for(String tvname:tv)
            System.out.println(tvname);
    }
    public static void getelectronic(){
        for(String elename:electronics)
            System.out.println(elename);
    }
}